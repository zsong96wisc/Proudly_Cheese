README

Course: cs400
Semester: Spring 2020
Project name: Proudly_Cheese
Team Members:
1. Hairong Yin, Lec 002, and hyin55@wisc.edu
2. Haonan Shen, Lec 001, and hshen37@wisc.edu
3. Xiaoxi Sun, Lec 002, and xsun279@wisc.edu
4. Zhiwei Song, Lec 002, and zsong96@wisc.edu
 
Which team members were on same xteam together?
None

Data specification:
1. The input csv file requires the first time to the title of the column because the program skipps the first line in files. 
2. The date format is YYYY-MM-DD.

Known bug: None

Future plan:
1. add charts to the result panes
2. Improve the efficiency when storing data
3. Export files contents based on asc/des sequence 

Other notes or comments to the grader:
